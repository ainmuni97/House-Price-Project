from flask import Flask, render_template, redirect, url_for, session
from flask_wtf import FlaskForm
from wtforms import TextField, SubmitField
from wtforms.validators import NumberRange
from joblib import dump,load
app = Flask(__name__)

app.config['SECRET_KEY'] = 'Aloha'



class HouseForm(FlaskForm):
	MSSubClass = TextField("MS_SubClass")
	MSZoning = TextField("Zone")
	LotFrontage = TextField("Lot_Frontage")
	LotArea = TextField("Lot_Area")
	Street = TextField("Street")
	LotShape = TextField("Lot_Shape")
	LandContour = TextField("Land_Contour")
	Utilities = TextField("Utilities")
	LotConfig = TextField("Lot_Configuration")
	LandSlope = TextField("Land_Slope")
	Neighborhood = TextField("Neighborhood")
	Condition1 = TextField("Condition_One")
	Condition2 = TextField("Condition_Two")
	BldgType = TextField("Type_Dwelling")
	HouseStyle = TextField("Style_Dwelling")
	OverallQual = TextField("Overall_Quality")
	OverallCond = TextField("Overall_Condition")
	YearBuilt = TextField("Year_Built")
	YearRemodAdd = TextField("Year_Remod/Add")
	RoofStyle = TextField("Roof_Style")
	RoofMatl = TextField("Roof_Material")
	Exterior1st = TextField("Exterior_1st")
	Exterior2nd = TextField("Exterior_2nd")
	MasVnrType = TextField("Masonry_veneer_Type")
	MasVnrArea = TextField("Masonry_veneer_Area")
	ExterQual = TextField("Exter_Quality")
	ExterCond = TextField("Exter_Condition")
	Foundation = TextField("Foundation")
	BsmtQual = TextField("Basement_Quality")
	BsmtCond = TextField("Basement_Condition")
	BsmtExposure = TextField("Basement_Exposure")
	BsmtFinType1 = TextField("Basement_Type 1")
	BsmtFinSF1 = TextField("Basement_Area_1")
	BsmtFinType2 = TextField("Basement_Type_2")
	BsmtFinSF2 = TextField("Basement_Area_2")
	BsmtUnfSF = TextField("Unfinished_Basement_Area")
	TotalBsmtSF = TextField("Total_Basement_Area")
	Heating = TextField("Heating")
	HeatingQC = TextField("Heating_Quality")
	CentralAir = TextField("Air_Condition")
	Electrical = TextField("Electrical")
	FstFlrSF = TextField("First_Floor_Area")
	SndFlrSF = TextField("Second_Floor_Area")
	LowQualFinSF = TextField("Low_Quality_Finished_Area")
	GrLivArea = TextField("Ground_Living_Area")
	BsmtFullBath = TextField("Basement_Full_Bathroom")
	BsmtHalfBath = TextField("Basement_Half_Bathroom")
	FullBath = TextField("Full_Bathroom")
	HalfBath = TextField("Half_Bathroom")
	BedroomAbvGr = TextField("Bedroom_Above_Grade")
	KitchenAbvGr = TextField("Kitchen_Above_Grade")
	KitchenQual = TextField("Kitchen_Quality")
	TotRmsAbvGrd = TextField("Total_Room_Above_Grade")
	Functional = TextField("Functional")
	Fireplaces = TextField("Fireplaces")
	FireplaceQu = TextField("Fireplace_Quality")
	GarageType = TextField("Garage_Type")
	GarageYrBlt = TextField("Garage_Year_Built")
	GarageFinish = TextField("Garage_Finish")
	GarageCars = TextField("Garage_Cars")
	GarageArea = TextField("Garage_Area")
	GarageQual = TextField("Garage_Quality")
	GarageCond = TextField("Garage_Condition")
	PavedDrive = TextField("Paved_Drive")
	WoodDeckSF = TextField("Wood_Deck_Area")
	OpenPorchSF = TextField("Open_Porch_Area")
	EnclosedPorch = TextField("Enclosed_Porch")
	ThreeSsnPorch = TextField("Three_season_Porch_Area")
	ScreenPorch = TextField("Screen_Porch")
	PoolArea = TextField("Pool_Area")
	MiscVal = TextField("Miscellaneous_Value")
	MoSold = TextField("Month_Sold")
	YrSold = TextField("Year_Sold")
	SaleType = TextField("Sale_Type")
	SaleCondition = TextField("Sale_Condition")

	submit = SubmitField('Price Predict')


@app.route('/', methods = ['GET', 'POST'])
def index():

    #Create From
    form = HouseForm()

    if form.validate_on_submit():
    	session['MSSubClass'] = form.MSSubClass.data
    	session['MSZoning'] = form.MSZoning.data
    	session['LotFrontage'] = form.LotFrontage.data
    	session['LotArea'] = form.LotArea.data
    	session['Street'] = form.Street.data
    	session['LotShape'] = form.LotShape.data
    	session['LandContour'] = form.LandContour.data
    	session['Utilities'] = form.Utilities.data
    	session['LotConfig'] = form.LotConfig.data
    	session['LandSlope'] = form.LandSlope.data
    	session['Neighborhood'] = form.Neighborhood.data
    	session['Condition1'] = form.Condition1.data
    	session['Condition2'] = form.Condition2.data
    	session['BldgType'] = form.BldgType.data
    	session['HouseStyle'] = form.HouseStyle.data
    	session['OverallQual'] = form.OverallQual.data
    	session['OverallCond'] = form.OverallCond.data
    	session['YearBuilt'] = form.YearBuilt.data
    	session['YearRemodAdd'] = form.YearRemodAdd.data
    	session['RoofStyle'] = form.RoofStyle.data
    	session['RoofMatl'] = form.RoofMatl.data
    	session['Exterior1st'] = form.Exterior1st.data
    	session['Exterior2nd'] = form.Exterior2nd.data
    	session['MasVnrType'] = form.MasVnrType.data
    	session['MasVnrArea'] = form.MasVnrArea.data
    	session['ExterQual'] = form.ExterQual.data
    	session['ExterCond'] = form.ExterCond.data
    	session['Foundation'] = form.Foundation.data
    	session['BsmtQual'] = form.BsmtQual.data
    	session['BsmtCond'] = form.BsmtCond.data
    	session['BsmtExposure'] = form.BsmtExposure.data
    	session['BsmtFinType1'] = form.BsmtFinType1.data
    	session['BsmtFinSF1'] = form.BsmtFinSF1.data
    	session['BsmtFinType2'] = form.BsmtFinType2.data
    	session['BsmtFinSF2'] = form.BsmtFinSF2.data
    	session['BsmtUnfSF'] = form.BsmtUnfSF.data
    	session['TotalBsmtSF'] = form.TotalBsmtSF.data
    	session['Heating'] = form.Heating.data
    	session['HeatingQC'] = form.HeatingQC.data
    	session['CentralAir'] = form.CentralAir.data
    	session['Electrical'] = form.Electrical.data
    	session['FstFlrSF'] = form.FstFlrSF.data
    	session['SndFlrSF'] = form.SndFlrSF.data
    	session['LowQualFinSF'] = form.LowQualFinSF.data
    	session['GrLivArea'] = form.GrLivArea.data
    	session['BsmtFullBath'] = form.BsmtFullBath.data
    	session['BsmtHalfBath'] = form.BsmtHalfBath.data
    	session['FullBath'] = form.FullBath.data
    	session['HalfBath'] = form.HalfBath.data
    	session['BedroomAbvGr'] = form.BedroomAbvGr.data
    	session['KitchenAbvGr'] = form.KitchenAbvGr.data
    	session['KitchenQual'] = form.KitchenQual.data
    	session['TotRmsAbvGrd'] = form.TotRmsAbvGrd.data
    	session['Functional'] = form.Functional.data
    	session['Fireplaces'] = form.Fireplaces.data
    	session['FireplaceQu'] = form.FireplaceQu.data
    	session['GarageType'] = form.GarageType.data
    	session['GarageYrBlt'] = form.GarageYrBlt.data
    	session['GarageFinish'] = form.GarageFinish.data
    	session['GarageCars'] = form.GarageCars.data
    	session['GarageArea'] = form.GarageArea.data
    	session['GarageQual'] = form.GarageQual.data
    	session['GarageCond'] = form.GarageCond.data
    	session['PavedDrive'] = form.PavedDrive.data
    	session['WoodDeckSF'] = form.WoodDeckSF.data
    	session['OpenPorchSF'] = form.OpenPorchSF.data
    	session['EnclosedPorch'] = form.EnclosedPorch.data
    	session['ThreeSsnPorch'] = form.ThreeSsnPorch.data
    	session['ScreenPorch'] = form.ScreenPorch.data
    	session['PoolArea'] = form.PoolArea.data
    	session['MiscVal'] = form.MiscVal.data
    	session['MoSold'] = form.MoSold.data
    	session['YrSold'] = form.YrSold.data
    	session['SaleType'] = form.SaleType.data
    	session['SaleCondition'] = form.SaleCondition.data
    	print(form.MSSubClass.data)
    	print(form.MSZoning.data)
    	print(form.LotFrontage.data)
    	print(form.LotArea.data)
    	print(form.Street.data)
    	print(form.LotShape.data)
    	print(form.LandContour.data)
    	print(form.Utilities.data)
    	print(form.LotConfig.data)
    	print(form.LandSlope.data)
    	print(form.Neighborhood.data)
    	print(form.Condition1.data)
    	print(form.Condition2.data)
    	print(form.BldgType.data)
    	print(form.HouseStyle.data)
    	print(form.OverallQual.data)
    	print(form.OverallCond.data)
    	print(form.YearBuilt.data)
    	print(form.YearRemodAdd.data)
    	print(form.RoofStyle.data)
    	print(form.RoofMatl.data)
    	print(form.Exterior1st.data)
    	print(form.Exterior2nd.data)
    	print(form.MasVnrType.data)
    	print(form.MasVnrArea.data)
    	print(form.ExterQual.data)
    	print(form.ExterCond.data)
    	print(form.Foundation.data)
    	print(form.BsmtQual.data)
    	print(form.BsmtCond.data)
    	print(form.BsmtExposure.data)
    	print(form.BsmtFinType1.data)
    	print(form.BsmtFinSF1.data)
    	print(form.BsmtFinType2.data)
    	print(form.BsmtFinSF2.data)
    	print(form.BsmtUnfSF.data)
    	print(form.TotalBsmtSF.data)
    	print(form.Heating.data)
    	print(form.HeatingQC.data)
    	print(form.CentralAir.data)
    	print(form.Electrical.data)
    	print(form.FstFlrSF.data)
    	print(form.SndFlrSF.data)
    	print(form.LowQualFinSF.data)
    	print(form.GrLivArea.data)
    	print(form.BsmtFullBath.data)
    	print(form.BsmtHalfBath.data)
    	print(form.FullBath.data)
    	print(form.HalfBath.data)
    	print(form.BedroomAbvGr.data)
    	print(form.KitchenAbvGr.data)
    	print(form.KitchenQual.data)
    	print(form.TotRmsAbvGrd.data)
    	print(form.Functional.data)
    	print(form.Fireplaces.data)
    	print(form.FireplaceQu.data)
    	print(form.GarageType.data)
    	print(form.GarageYrBlt.data)
    	print(form.GarageFinish.data)
    	print(form.GarageCars.data)
    	print(form.GarageArea.data)
    	print(form.GarageQual.data)
    	print(form.GarageCond.data)
    	print(form.PavedDrive.data)
    	print(form.WoodDeckSF.data)
    	print(form.OpenPorchSF.data)
    	print(form.EnclosedPorch.data)
    	print(form.ThreeSsnPorch.data)
    	print(form.ScreenPorch.data)
    	print(form.PoolArea.data)
    	print(form.MiscVal.data)
    	print(form.MoSold.data)
    	print(form.YrSold.data)
    	print(form.SaleType.data)
    	print(form.SaleCondition.data)

    	return redirect(url_for("prediction"))

    return render_template('AmesHome.html', form =form)


@app.route('/prediction')
def prediction():

		content = {}
		content['MS_SubClass']=float(session['MSSubClass'])
		content['Zone'] =str(session['MSZoning'])
		content['Lot_Frontage'] =float(session['LotFrontage'])
		content['Lot_Area'] =float(session['LotArea'])
		content['Street'] =str(session['Street'])
		content['Lot_Shape'] =str(session['LotShape'])
		content['Land_Contour'] =str(session['LandContour'])
		content['Utilities'] =str(session['Utilities'])
		content['Lot_Configuration'] =str(session['LotConfig'])
		content['Land_Slope'] =str(session['LandSlope'])
		content['Neighborhood'] =str(session['Neighborhood'])
		content['Condition_One'] =str(session['Condition1'])
		content['Condition_Two'] =str(session['Condition2'])
		content['Type_Dwelling'] =str(session['BldgType'])
		content['Style_Dwelling'] =str(session['HouseStyle'])
		content['Overall_Quality'] =float(session['OverallQual'])
		content['Overall_Condition'] =float(session['OverallCond'])
		content['Year_Built'] =float(session['YearBuilt'])
		content['Year_Remod/Add'] =float(session['YearRemodAdd'])
		content['Roof_Style'] =str(session['RoofStyle'])
		content['Roof_Material'] =str(session['RoofMatl'])
		content['Exterior_1st'] =str(session['Exterior1st'])
		content['Exterior_2nd'] =str(session['Exterior2nd'])
		content['Masonry_veneer_Type'] =str(session['MasVnrType'])
		content['Masonry_veneer_Area'] =float(session['MasVnrArea'])
		content['Exter_Quality'] =str(session['ExterQual'])
		content['Exter_Condition'] =str(session['ExterCond'])
		content['Foundation'] =str(session['Foundation'])
		content['Basement_Quality'] =str(session['BsmtQual'])
		content['Basement_Condition'] =str(session['BsmtCond'])
		content['Basement_Exposure'] =str(session['BsmtExposure'])
		content['Basement_Type_1'] =str(session['BsmtFinType1'])
		content['Basement_Area_1'] =float(session['BsmtFinSF1'])
		content['Basement_Type_2'] =str(session['BsmtFinType2'])
		content['Basement_Area_2'] =float(session['BsmtFinSF2'])
		content['Unfinished_Basement_Area'] =float(session['BsmtUnfSF'])
		content['Total_Basement_Area'] =float(session['TotalBsmtSF'])
		content['Heating'] =str(session['Heating'])
		content['Heating_Quality'] =str(session['HeatingQC'])
		content['Air_Condition'] =str(session['CentralAir'])
		content['Electrical'] =str(session['Electrical'])
		content['First_Floor_Area'] =float(session['FstFlrSF'])
		content['Second_Floor_Area'] =float(session['SndFlrSF'])
		content['Low_Quality_Finished_Area'] =float(session['LowQualFinSF'])
		content['Ground_Living_Area'] =float(session['GrLivArea'])
		content['Basement_Full_Bathroom'] =float(session['BsmtFullBath'])
		content['Basement_Half_Bathroom'] =float(session['BsmtHalfBath'])
		content['Full_Bathroom'] =float(session['FullBath'])
		content['Half_Bathroom'] =float(session['HalfBath'])
		content['Bedroom_Above_Grade'] =float(session['BedroomAbvGr'])
		content['Kitchen_Above_Grade'] =float(session['KitchenAbvGr'])
		content['Kitchen_Quality'] =str(session['KitchenQual'])
		content['Total_Room_Above_Grade'] =float(session['TotRmsAbvGrd'])
		content['Functional'] =str(session['Functional'])
		content['Fireplaces'] =float(session['Fireplaces'])
		content['Fireplace_Quality'] =str(session['FireplaceQu'])
		content['Garage_Type'] =str(session['GarageType'])
		content['Garage_Year_Built'] =float(session['GarageYrBlt'])
		content['Garage_Finish'] =str(session['GarageFinish'])
		content['Garage_Cars'] =float(session['GarageCars'])
		content['Garage_Area'] =float(session['GarageArea'])
		content['Garage_Quality'] =str(session['GarageQual'])
		content['Garage_Condition'] =str(session['GarageCond'])
		content['Paved_Drive'] =str(session['PavedDrive'])
		content['Wood_Deck_Area'] =float(session['WoodDeckSF'])
		content['Open_Porch_Area'] =float(session['OpenPorchSF'])
		content['Enclosed_Porch'] =float(session['EnclosedPorch'])
		content['Three_season_Porch_Area'] =float(session['ThreeSsnPorch'])
		content['Screen_Porch'] =float(session['ScreenPorch'])
		content['Pool_Area'] =float(session['PoolArea'])
		content['Miscellaneous_Value'] =float(session['MiscVal'])
		content['Month_Sold'] =float(session['MoSold'])
		content['Year_Sold'] =float(session['YrSold'])
		content['Sale_Type'] =str(session['SaleType'])
		content['Sale_Condition'] =str(session['SaleCondition'])
	
	
		results = return_prediction(model= Ames_model,sample_json= content, scaler=Ames_scaler)
		print(results)
		return render_template('AmesPrediction.html',results = results)

#3 Add the return_predicton()


def mszoning(Zone):
    
    if Zone == 'C':
        return [1,0,0,0,0,0]
    elif Zone == 'FV':
        return [0,1,0,0,0,0]
    elif Zone == 'I':
        return [0,0,1,0,0,0]
    elif Zone == 'RH':
        return [0,0,0,1,0,0]
    elif Zone == 'RL':
        return [0,0,0,0,1,0]
    elif Zone == 'RM':
        return [0,0,0,0,0,1]
    else:
        return [0,0,0,0,0,0]

def street(Street):
    if Street == 'Pave':
        return [1]
    else:
        return [0]

def lotshape(Lot_Shape):
    if Lot_Shape == 'IR2':
        return [1,0,0]
    elif Lot_Shape == 'IR3':
        return [0,1,0]
    elif Lot_Shape == 'Reg':
        return [0,0,1]
    else:
        return [0,0,0]

def landcontour(Land_Countour):
    if Land_Countour == 'HLS':
        return [1,0,0]
    elif Land_Countour == 'Low':
        return [0,1,0]
    elif Land_Countour == ' Lvl':
        return [0,0,1]
    else:
        return [0,0,0]

def utilities(Utilities):
    if Utilities == 'NoSewa':
        return [1,0]
    elif Utilities == 'NoSewr':
        return [0,1]
    else:
        return [0,0]

def lotconfig(Lot_Configuration):
    if Lot_Configuration =='CulDSac':
        return [1,0,0,0]
    elif Lot_Configuration =='FR2':
        return [0,1,0,0]
    elif Lot_Configuration =='FR3':
        return [0,0,1,0]
    elif Lot_Configuration =='Inside':
        return [0,0,0,1]
    else:
        return [0,0,0,0]

def landslope(Land_Slope):
    if Land_Slope=='Gtl':
        return [2]
    elif Land_Slope=='Mod':
        return [1]
    elif Land_Slope=='Sev':
        return [0]

def neighborhood(Neighborhood):
    if Neighborhood =='Blueste':
        return [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    elif Neighborhood =='BrDale':
        return [0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    elif Neighborhood =='BrkSide':
        return [0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    elif Neighborhood =='ClearCr':
        return [0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    elif Neighborhood =='CollgCr':
        return [0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    elif Neighborhood =='Crawfor':
        return [0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    elif Neighborhood =='Edwards':
        return [0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    elif Neighborhood =='Gilbert':
        return [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    elif Neighborhood =='Greens':
        return [0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    elif Neighborhood =='GrnHill':
        return [0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    elif Neighborhood =='IDOTRR':
        return [0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    elif Neighborhood =='Landmrk':
        return [0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    elif Neighborhood =='MeadowV':
        return [0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    elif Neighborhood =='Mitchel':
        return [0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0]
    elif Neighborhood =='NAmes':
        return [0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0]
    elif Neighborhood=='NPkVill':
        return [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0]
    elif Neighborhood =='NWAmes':
        return [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0]
    elif Neighborhood =='NoRidge':
        return [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0]
    elif Neighborhood =='NridgHt':
        return [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0]
    elif Neighborhood =='OldTown':
        return [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0]
    elif Neighborhood =='SWISU':
        return [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0]
    elif Neighborhood =='Sawyer':
        return [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0]
    elif Neighborhood =='SawyerW':
        return [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0]
    elif Neighborhood =='Somerst':
        return [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0]
    elif Neighborhood =='StoneBr':
        return [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0]
    elif Neighborhood =='Timber':
        return [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0]
    elif Neighborhood =='Veenker':
        return [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1]
    else:
        return [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
          
def condition1 (Condition_One):
    if Condition_One == 'Feedr':
        return [1,0,0,0,0,0,0,0]
    elif Condition_One == 'Norm':
        return [0,1,0,0,0,0,0,0]
    elif Condition_One == 'PosA':
        return [0,0,1,0,0,0,0,0]
    elif Condition_One == 'PosN':
        return [0,0,0,1,0,0,0,0]
    elif Condition_One == 'RRAe':
        return [0,0,0,0,1,0,0,0]
    elif Condition_One == 'RRAn':
        return [0,0,0,0,0,1,0,0]
    elif Condition_One == 'RRNe':
        return [0,0,0,0,0,0,1,0]
    elif Conditiion_One == 'RRNn':
        return [0,0,0,0,0,0,0,1]
    else:
        return [0,0,0,0,0,0,0,0]   

def condition2 (Condition_Two):
    if Condition_Two == 'Feedr':
        return [1,0,0,0,0,0,0]
    elif Condition_Two == 'Norm':
        return [0,1,0,0,0,0,0]
    elif Condition_Two == 'PosA':
        return [0,0,1,0,0,0,0]
    elif Condition_Two == 'PosN':
        return [0,0,0,1,0,0,0]
    elif Condition_Two == 'RRAe':
        return [0,0,0,0,1,0,0]
    elif Condition_Two == 'RRAn':
        return [0,0,0,0,0,1,0]
    elif Conditiion_Two == 'RRNn':
        return [0,0,0,0,0,0,1]
    else:
        return [0,0,0,0,0,0,0]        

def bldgtype(Type_Dwelling):
    if Type_Dwelling == '2fmCon':
        return [1,0,0,0]
    elif Type_Dwelling == 'Duplex':
        return [0,1,0,0]
    elif Type_Dwelling == 'Twnhs':
        return [0,0,1,0]
    elif Type_Dwelling == 'TwnhsE':
        return [0,0,0,1]
    else:
        return [0,0,0,0]

def housestyle(Style_Dwelling):
    if Style_Dwelling == '1.5Unf':
        return [1,0,0,0,0,0,0]
    elif Style_Dwelling == '1Story':
        return [0,1,0,0,0,0,0]
    elif Style_Dwelling == '2.5in':
        return [0,0,1,0,0,0,0]
    elif Style_Dwelling == '2.5Unf':
        return [0,0,0,1,0,0,0]
    elif Style_Dwelling == '2Story':
        return [0,0,0,0,1,0,0]
    elif Style_Dwelling == 'SFoyer':
        return [0,0,0,0,0,1,0]
    elif Style_Dwelling == 'SLvl':
        return [0,0,0,0,0,0,1]
    else:
        return [0,0,0,0,0,0,0]    
        
def roofstyle(Roof_Style):
    if Roof_Style == 'Gable':
        return [1,0,0,0,0]
    elif Roof_Style == 'Gambrel':
        return [0,1,0,0,0]
    elif Roof_Style == 'Hip':
        return [0,0,1,0,0]
    elif Roof_Style == 'Mansard':
        return [0,0,0,1,0]
    elif Roof_Style == 'Shed':
        return [0,0,0,0,1]
    else:
        return [0,0,0,0,0]  

def roofmatl(Roof_Material):
    if Roof_Material == 'Membran':
        return [1,0,0,0,0,0]
    elif Roof_Material == 'Metal':
        return [0,1,0,0,0,0]
    elif Roof_Material == 'Roll':
        return [0,0,1,0,0,0]
    elif Roof_Material == 'Tar&Grv':
        return [0,0,0,1,0,0]
    elif Roof_Material == 'Wdshake':
        return [0,0,0,0,1,0]
    elif Roof_Material == 'WdShngl':
        return [0,0,0,0,0,1]
    else:
        return [0,0,0,0,0,0] 

def exterior1st(Exterior_1st):
    if Exterior_1st == 'AsphShn':
        return [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    elif Exterior_1st == 'BrkComm':
        return [0,1,0,0,0,0,0,0,0,0,0,0,0,0,0]
    elif Exterior_1st == 'BrkFace':
        return [0,0,1,0,0,0,0,0,0,0,0,0,0,0,0]
    elif Exterior_1st == 'CBlock':
        return [0,0,0,1,0,0,0,0,0,0,0,0,0,0,0]
    elif Exterior_1st == 'CemntBd':
        return [0,0,0,0,1,0,0,0,0,0,0,0,0,0,0]
    elif Exterior_1st == 'HdBoard':
        return [0,0,0,0,0,1,0,0,0,0,0,0,0,0,0]
    elif Exterior_1st == 'ImStucc':
        return [0,0,0,0,0,0,1,0,0,0,0,0,0,0,0]
    elif Exterior_1st == 'MetalSd':
        return [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0]
    elif Exterior_1st == 'Plywood':
        return [0,0,0,0,0,0,0,0,1,0,0,0,0,0,0]
    elif Exterior_1st == 'PreCast':
        return [0,0,0,0,0,0,0,0,0,1,0,0,0,0,0]
    elif Exterior_1st == 'Stone':
        return [0,0,0,0,0,0,0,0,0,0,1,0,0,0,0]
    elif Exterior_1st == 'Stucco':
        return [0,0,0,0,0,0,0,0,0,0,0,1,0,0,0]
    elif Exterior_1st == 'VinylSd':
        return [0,0,0,0,0,0,0,0,0,0,0,0,1,0,0]
    elif Exterior_1st == 'Wd Sdng':
        return [0,0,0,0,0,0,0,0,0,0,0,0,0,1,0]
    elif Exterior_1st == 'WdShing':
        return [0,0,0,0,0,0,0,0,0,0,0,0,0,0,1]
    else:
    	return [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]                 

def exterior2nd(Exterior_2nd):
    if Exterior_2nd == 'AsphShn':
        return [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    elif Exterior_2nd == 'Brk Comm':
        return [0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    elif Exterior_2nd == 'BrkFace':
        return [0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0]
    elif Exterior_2nd == 'CBlock':
        return [0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0]
    elif Exterior_2nd == 'CemntBd':
        return [0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0]
    elif Exterior_2nd == 'HdBoard':
        return [0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0]
    elif Exterior_2nd == 'ImStucc':
        return [0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0]
    elif Exterior_2nd == 'MetalSd':
        return [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0]
    elif Exterior_2nd == 'Other':
        return [0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0]
    elif Exterior_2nd == 'Plywood':
        return [0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0]
    elif Exterior_2nd == 'PreCast':
        return [0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0]
    elif Exterior_2nd == 'Stone':
        return [0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0]
    elif Exterior_2nd == 'Stucco':
        return [0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0]
    elif Exterior_2nd == 'VinylSd':
        return [0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0]
    elif Exterior_2nd == 'Wd Sdng':
        return [0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0]
    elif Exterior_2nd == 'Wd Shing':
        return [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1]
    else:
    	return [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

def masvnrtype(Masonry_veneer_Type):
    if Masonry_veneer_Type == 'BrkFace':
        return [1,0,0,0]
    elif Masonry_veneer_Type == 'CBlock':
        return [0,1,0,0]
    elif Masonry_veneer_Type == 'None':
        return [0,0,1,0]
    elif Masonry_veneer_Type == 'Stone':
        return [0,0,0,1]
    else:
        return [0,0,0,0]

def exterqual(Exterior_Quality):
    if Exterior_Quality == 'Po':
        return [0]
    elif Exterior_Quality == 'Fa':
        return [1]
    elif Exterior_Quality == 'TA':
        return [2]
    elif Exterior_Quality == 'Gd':
        return [3]        
    elif Exterior_Quality == 'Ex':
        return [4]

def extercond(Exterior_Condition):
    if Exterior_Condition == 'Po':
        return [0]
    elif Exterior_Condition == 'Fa':
        return [1]
    elif Exterior_Condition == 'TA':
        return [2]
    elif Exterior_Condition == 'Gd':
        return [3]   
    elif Exterior_Condition == 'Ex':
        return [4]

def foundation(Type_Foundation):
    if Type_Foundation=='CBlock':
        return [1,0,0,0,0]
    elif Type_Foundation =='PConc':
        return [0,1,0,0,0]
    elif Type_Foundation =='Slab':
        return [0,0,1,0,0]
    elif Type_Foundation =='Stone':
        return [0,0,0,1,0]
    elif Type_Foundation =='Wood':
        return [0,0,0,0,1] 
    else:
        return [0,0,0,0,0]

def bsmtqual(Basement_Quality):
    if Basement_Quality=='None':
        return [0]
    elif Basement_Quality =='Po':
        return [1]
    elif Basement_Quality =='Fa':
        return [2]
    elif Basement_Quality =='TA':
        return [3]
    elif Basement_Quality =='Gd':
        return [4] 
    elif Basement_Quality =='Ex':
        return [5] 
    
def bsmtcond(Basement_Condition):
    if Basement_Condition=='None':
        return [0]
    elif Basement_Condition =='Po':
        return [1]
    elif Basement_Condition =='Fa':
        return [2]
    elif Basement_Condition=='TA':
        return [3]
    elif Basement_Condition =='Gd':
        return [4] 
    elif Basement_Condition =='Ex':
        return [5] 
   
def bsmtexposure(Basement_Exposure):
    if Basement_Exposure =='None':
        return [0]
    elif Basement_Exposure =='No':
        return [1]
    elif Basement_Exposure =='Mn':
        return [2]
    elif Basement_Exposure =='Av':
        return [3] 
    elif Basement_Exposure =='Gd':
        return [4] 

def bsmtfintype1(Basement_Type1):
    if Basement_Type1=='GLQ':
        return [6]
    elif Basement_Type1 =='ALQ':
        return [5]
    elif Basement_Type1 =='BLQ':
        return [4]
    elif Basement_Type1=='Rec':
        return [3] 
    elif Basement_Type1 =='LwQ':
        return [2]
    elif Basement_Type1=='Unf':
        return [1]
    elif Basement_Type1=='None':
        return [0]
   
def bsmtfintype2(Basement_Type2):
    if Basement_Type2=='GLQ':
        return [6]
    elif Basement_Type2 =='ALQ':
        return [5]
    elif Basement_Type2 =='BLQ':
        return [4]
    elif Basement_Type2 =='Rec':
        return [3]        
    elif Basement_Type2 =='LwQ':
        return [2]
    elif Basement_Type2 =='Unf':
        return [1]
    elif Basement_Type2 =='None':
        return [0

        ]

def heating(Heating):
    if Heating =='GasA':
        return [1,0,0,0,0]
    elif Heating =='GasW':
        return [0,1,0,0,0]
    elif Heating =='Grav':
        return [0,0,1,0,0]
    elif Heating =='Othw':
        return [0,0,0,1,0]
    elif Heating =='Wall':
        return [0,0,0,0,1] 
    else:
        return [0,0,0,0,0]
    
def heatingqc(Heating_Quality):
    if Heating_Quality =='Po':
        return [0]
    elif Heating_Quality =='Fa':
        return [1]
    elif Heating_Quality =='TA':
        return [2]
    elif Heating_Quality =='Gd':
        return [3] 
    elif Heating_Quality =='Ex':
        return [4]

def centralair(Air_Conditioning):
    if Air_Conditioning == 'Y':
        return [1]
    else:
        return [0]
    
def electrical(Electrical_System):
    if Electrical_System=='FuseF':
        return [1,0,0,0]
    elif Electrical_System=='FuseP':
        return [0,1,0,0]
    elif Electrical_System=='Mix':
        return [0,0,1,0]
    elif Electrical_System=='SBrkr':
        return [0,0,0,1]
    else:
        return [0,0,0,0]
    
def kitchenqual(Kitchen_Quality):
    if Kitchen_Quality =='Po':
        return [0]
    elif Kitchen_Quality =='Fa':
        return [1]
    elif Kitchen_Quality =='TA':
        return [2]
    elif Kitchen_Quality =='Gd':
        return [3] 
    elif Kitchen_Quality =='Ex':
        return [4]
    
def functional(Home_Function):
    if Home_Function == 'Sal':
        return [0]
    elif Home_Function == 'Sev':
        return [1]
    elif Home_Function == 'Maj2':
        return [2]
    elif Home_Function == 'Maj1':
        return [3]
    elif Home_Function == 'Mod':
        return [4]
    elif Home_Function == 'Min2':
        return [5]
    elif Home_Function == 'Min1':
        return [6]        
    elif Home_Function == 'Typ':
        return [7]

def fireplacequ(Fireplace_Quality):
    if Fireplace_Quality =='None':
        return [0]
    elif Fireplace_Quality =='Po':
        return [1]
    elif Fireplace_Quality =='Fa':
        return [2]
    elif Fireplace_Quality =='TA':
        return [3]
    elif Fireplace_Quality =='Gd':
        return [4] 
    elif Fireplace_Quality =='Ex':
        return [5] 
    
def garagetype(Garage_Type):
    if Garage_Type =='Attchd':
        return [1,0,0,0,0,0]
    elif Garage_Type =='Basement':
        return [0,1,0,0,0,0]
    elif Garage_Type =='BuiltIn':
        return [0,0,1,0,0,0]
    elif Garage_Type =='CarPort':
        return [0,0,0,1,0,0]
    elif Garage_Type =='Detchd':
        return [0,0,0,0,1,0]
    elif Garage_Type =='None':
        return [0,0,0,0,0,1]
    else:
        return [0,0,0,0,0,0]
    
def garagefinish(Garage_Finish):
    if Garage_Finish =='None':
        return [1,0,0]
    elif Garage_Finish =='RFn':
        return [0,1,0]
    elif Garage_Finish =='Unf':
        return [0,0,1]
    else:
        return [0,0,0]
    
def garagequal(Garage_Quality):
    if Garage_Quality =='None':
        return [0]
    elif Garage_Quality =='Po':
        return [1]
    elif Garage_Quality =='Fa':
        return [2]
    elif Garage_Quality =='TA':
        return [3]
    elif Garage_Quality =='Gd':
        return [4]
    elif Garage_Quality =='Ex':
        return [5]
    
def garagecond(Garage_Condition):
    if Garage_Condition =='None':
        return [0]
    elif Garage_Condition =='Po':
        return [1]
    elif Garage_Condition =='Fa':
        return [2]
    elif Garage_Condition =='TA':
        return [3]
    elif Garage_Condition =='Gd':
        return [4]
    elif Garage_Condition =='Ex':
        return [6]
    
def paveddrive(Paved_Drive):
    if Paved_Drive == 'N':
        return [0]
    elif Paved_Drive == 'P':
        return [1]        
    elif Paved_Drive == 'Y':
        return [2]

def saletype(Sale_Type):
    if Sale_Type =='CWD':
        return [1,0,0,0,0,0,0,0,0]
    elif Sale_Type =='Con':
        return [0,1,0,0,0,0,0,0,0]
    elif Sale_Type =='ConLD':
        return [0,0,1,0,0,0,0,0,0]
    elif Sale_Type =='ConLI':
        return [0,0,0,1,0,0,0,0,0]
    elif Sale_Type =='ConLw':
        return [0,0,0,0,1,0,0,0,0]
    elif Sale_Type =='New':
        return [0,0,0,0,0,1,0,0,0]
    elif Sale_Type=='Oth':
        return [0,0,0,0,0,0,1,0,0]
    elif Sale_Type =='VWD':
        return [0,0,0,0,0,0,0,1,0]
    elif Sale_Type =='WD':
        return [0,0,0,0,0,0,0,0,1]
    else:
        return [0,0,0,0,0,0,0,0,0]
    
def salecondition(Sale_Condition):
    if Sale_Condition =='AdjLand':
        return [1,0,0,0,0]
    elif Sale_Condition =='Alloca':
        return [0,1,0,0,0]
    elif Sale_Condition =='Family':
        return [0,0,1,0,0]
    elif Sale_Condition =='Normal':
        return [0,0,0,1,0]
    elif Sale_Condition =='Partial':
        return [0,0,0,0,1]
    else:
        return [0,0,0,0,0]


def return_prediction(model,sample_json,scaler):
    #For Larger data features, you should probably write
    #That builds out this array for you

	

	#Yang belum jadi list, buat jadi list dulu
	MSSubClass = sample_json['MS_SubClass']
	LotFrontage = sample_json['Lot_Frontage']
	LotArea = sample_json['Lot_Area']

	price = [MSSubClass,LotFrontage,LotArea]

	LandSlope = landslope(sample_json['Land_Slope'])
	price = price+LandSlope

	OverallQual = sample_json['Overall_Quality']
	OverallCond = sample_json['Overall_Condition']
	YearBuilt = sample_json['Year_Built']
	YearRemodAdd = sample_json['Year_Remod/Add']
	MasVnrArea = sample_json['Masonry_veneer_Area']

	price = price+[OverallQual,OverallCond,YearBuilt,YearRemodAdd,MasVnrArea]

	ExterQual = exterqual(sample_json['Exter_Quality'])
	ExterCond = extercond(sample_json['Exter_Condition'])
	BsmtQual = bsmtqual(sample_json['Basement_Quality'])
	BsmtCond = bsmtcond(sample_json['Basement_Condition'])
	BsmtExposure = bsmtexposure(sample_json['Basement_Exposure'])
	BsmtFinType1 = bsmtfintype1(sample_json['Basement_Type_1'])

	price = price+ExterQual+ExterCond+BsmtQual+BsmtCond+BsmtExposure+BsmtFinType1

	BsmtFinSF1 = sample_json['Basement_Area_1']
	price = price+[BsmtFinSF1]

	BsmtFinType2 = bsmtfintype2(sample_json['Basement_Type_2'])

	price = price+BsmtFinType2

	BsmtFinSF2 = sample_json['Basement_Area_2']
	BsmtUnfSF = sample_json['Unfinished_Basement_Area']
	TotalBsmtSF = sample_json['Total_Basement_Area']

	price = price + [BsmtFinSF2,BsmtUnfSF,TotalBsmtSF]

	HeatingQC = heatingqc(sample_json['Heating_Quality'])

	price = price+HeatingQC

	FstFlrSF = sample_json['First_Floor_Area']
	SndFlrSF = sample_json['Second_Floor_Area']
	LowQualFinSF = sample_json['Low_Quality_Finished_Area']
	GrLivArea = sample_json['Ground_Living_Area']
	BsmtFullBath = sample_json['Basement_Full_Bathroom']
	BsmtHalfBath = sample_json['Basement_Half_Bathroom']
	FullBath = sample_json['Full_Bathroom']
	HalfBath = sample_json['Half_Bathroom']
	BedroomAbvGr = sample_json['Bedroom_Above_Grade']
	KitchenAbvGr = sample_json['Kitchen_Above_Grade']

	price = price + [FstFlrSF,SndFlrSF,LowQualFinSF,GrLivArea,BsmtFullBath,BsmtHalfBath,FullBath,HalfBath,BedroomAbvGr,KitchenAbvGr]

	KitchenQual = kitchenqual(sample_json['Kitchen_Quality'])

	price = price+KitchenQual

	TotRmsAbvGrd = sample_json['Total_Room_Above_Grade']

	price = price +[TotRmsAbvGrd]

	Functional = functional(sample_json['Functional'])

	price = price+Functional

	Fireplaces = sample_json['Fireplaces']

	price = price +[Fireplaces]

	FireplaceQu = fireplacequ(sample_json['Fireplace_Quality'])

	price = price+FireplaceQu

	GarageYrBlt = sample_json['Garage_Year_Built']
	GarageCars = sample_json['Garage_Cars']
	GarageArea = sample_json['Garage_Area']

	price = price + [GarageYrBlt,GarageCars,GarageArea]

	GarageQual = garagequal(sample_json['Garage_Quality'])
	GarageCond = garagecond(sample_json['Garage_Condition'])
	PavedDrive = paveddrive(sample_json['Paved_Drive'])

	price = price+GarageQual+GarageCond+PavedDrive

	WoodDeckSF = sample_json['Wood_Deck_Area']
	OpenPorchSF = sample_json['Open_Porch_Area']
	EnclosedPorch = sample_json['Enclosed_Porch']
	ThreeSsnPorch = sample_json['Three_season_Porch_Area']
	ScreenPorch = sample_json['Screen_Porch']
	PoolArea = sample_json['Pool_Area']
	MiscVal = sample_json['Miscellaneous_Value']
	MoSold = sample_json['Month_Sold']
	YrSold = sample_json['Year_Sold']

	price = price + [WoodDeckSF,OpenPorchSF,EnclosedPorch,ThreeSsnPorch,ScreenPorch,PoolArea,MiscVal,MoSold,YrSold]

	MSZoning = mszoning(sample_json['Zone'])
	Street = street(sample_json['Street'])
	LotShape = lotshape(sample_json['Lot_Shape'])
	LandContour = landcontour(sample_json['Land_Contour'])
	Utilities = utilities(sample_json['Utilities'])
	LotConfig = lotconfig(sample_json['Lot_Configuration'])
	Neighborhood = neighborhood(sample_json['Neighborhood'])
	Condition1 = condition1(sample_json['Condition_One'])
	Condition2 = condition2(sample_json['Condition_Two'])
	BldgType = bldgtype(sample_json['Type_Dwelling'])
	HouseStyle = housestyle(sample_json['Style_Dwelling'])
	RoofStyle = roofstyle(sample_json['Roof_Style'])
	RoofMatl = roofmatl(sample_json['Roof_Material'])
	Exterior1st = exterior1st(sample_json['Exterior_1st'])
	Exterior2nd = exterior2nd(sample_json['Exterior_2nd'])
	MasVnrType = masvnrtype(sample_json['Masonry_veneer_Type'])
	Foundation = foundation(sample_json['Foundation'])
	Heating = heating(sample_json['Heating'])
	CentralAir = centralair(sample_json['Air_Condition'])
	Electrical = electrical(sample_json['Electrical'])
	GarageType = garagetype(sample_json['Garage_Type'])
	GarageFinish = garagefinish(sample_json['Garage_Finish'])
	SaleType = saletype(sample_json['Sale_Type'])
	SaleCondition = salecondition(sample_json['Sale_Condition'])

	price = price+MSZoning+Street+LotShape+LandContour+Utilities+LotConfig+Neighborhood+Condition1+Condition2+BldgType+HouseStyle+RoofStyle+RoofMatl+Exterior1st+Exterior2nd+MasVnrType+Foundation+Heating+CentralAir+Electrical+GarageType+GarageFinish+SaleType+SaleCondition


	Price = [price]
	#print(Price)
	Price = scaler.transform(Price)
	prediction =model.predict(Price)

	return prediction[0]
    #1 Load the Model
    #2 Load the Scaler

Ames_model = load("Ames_model.joblib")
Ames_scaler = load("Ames_scaler.pkl")

    
if __name__ == '__main__':
    app.run()